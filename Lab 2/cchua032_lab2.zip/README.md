# Lab 2

## Student information

* Full name: Chris Chua
* E-mail:cchua032
* UCR NetID:cchua032
* Student ID:862292532

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.

    - IsEven(5)
    - IsEven.apply(5)
    - new IsEven().apply(5)
    - C, new IsEven().apply(5) is the correct way to call the IsEven function. 
- **(Q2)** Did the program compile?

-It does not compile. 
- **(Q3)** If it does not work, what is the error message you get?
![CS167_LAB2.1.png](..%2F..%2F..%2FPictures%2FCS167_LAB2.1.png)