# CS167 Final Project
## Project D - Twitter Data Analysis
### Group 22

## Student information

### Task 1 - Data Preparation 1
* Completed files PreprocessTweets.scala & AnalyzeTweets.scala


* Full name: Robert Layco
* E-mail: rlayc001@ucr.edu
* UCR NetID: rlayc001
* Student ID: 862373211

### Task 2 - Data Preparation 2
* Completed file TopicExtraction.scala


* Full name: Daniel Do
* E-mail: ddo046@ucr.edu
* UCR NetID: ddo046
* Student ID: 862323415

### Task 3 - Topic Prediction
* Completed file TopicPrediction.scala


* Full name: Charlize Esparza
* E-mail: cespa014@ucr.edu
* UCR NetID: cespa014
* Student ID: 862305344

### Task 4 - Temporal Analysis
* Completed file TemporalAnalysis.scala


* Full name: Chris Chua
* E-mail: cchua032@ucr.edu
* UCR NetID: cchua032
* Student ID: 862292532